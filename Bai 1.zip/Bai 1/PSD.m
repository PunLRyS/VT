function PSD(A,T,fc)
%Pho tin hieu bang goc va bang thong



end

